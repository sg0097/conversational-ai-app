import { P, a } from "./mermaid-parser.core.CCfzgDhs.js";
export {
  P as PacketModule,
  a as createPacketServices
};
