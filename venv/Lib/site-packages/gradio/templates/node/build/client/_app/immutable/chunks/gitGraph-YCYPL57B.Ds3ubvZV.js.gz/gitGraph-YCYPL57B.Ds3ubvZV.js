import { G, f } from "./mermaid-parser.core.CCfzgDhs.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
