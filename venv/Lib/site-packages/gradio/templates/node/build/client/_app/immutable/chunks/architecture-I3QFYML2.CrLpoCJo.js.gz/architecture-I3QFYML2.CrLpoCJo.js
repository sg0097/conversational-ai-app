import { A, e } from "./mermaid-parser.core.CCfzgDhs.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
