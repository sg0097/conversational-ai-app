import { I, c } from "./mermaid-parser.core.CCfzgDhs.js";
export {
  I as InfoModule,
  c as createInfoServices
};
