import { X, _ } from "../chunks/2.NTZo4hh4.js";
export {
  X as component,
  _ as universal
};
